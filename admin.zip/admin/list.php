<?php
include_once'connect.php';
include_once'header.php';
?>
<div class="container">
<div class="row">
<div class="col-md-12">
<table class="table table-bordered" id="mytable">
<thead>
	
<th> sl_no</th>	
<th>email</th>
<th>password</th>
<th>type</th>
<th>status</th>
<th></th>
</thead>
<tbody>
<?php $sql="select * from login";
$i=1;
$result=mysqli_query($con,$sql);
while($row=mysqli_fetch_array($result))
{?>
	<tr>
		<td><?=$i?></td>
<td><?=$row['email']?></td>
<td><?=$row['password']?></td>
<td><?=$row['type']?></td>
<td><?=$row['status']?></td>
<td>
	<a class ="btn btn-danger" href="delete.php?id=<?=$row['user_id']?>" onclick ="return confirm('do you want to delete ?')">
	delete</a>
<a class ="btn btn-info" href="update.php?id=<?=$row['user_id']?>">
	update </a>
</td>

</tr>
<?php
$i++;}
?>
</tbody>
</table>
</div>
</div>
</div>
<?php include_once 'footer.php';?>
<script type="text/javascript">
	$(document).ready(function()
	{
		$('#mytable').DataTable();
	});
</script>
