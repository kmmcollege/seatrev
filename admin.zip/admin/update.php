<?php
include_once 'connect.php';
$id=$_GET['id'];
if (isset($_POST['btn'])) {
	$email=$_POST['email'];
	$pass=$_POST['password'];
	$sql="update login set email='$email',password='$pass' where user_id=$id";
	if (mysqli_query($con,$sql)) {
		?>
		<script type="text/javascript">
			alert("updated");
			window.location="list.php";
			
		</script>
		<?php
	}
}
$sql="select * from login where user_id=$id";
$result=mysqli_query($con,$sql);
$row=mysqli_fetch_array($result);
include_once 'header.php';
?>
<div class="container">
	<div class="row">
		<div class="col=md_6">
			<form class="form_group" method="POST">
				<label>email</label>
				<input type="text" name="email" class="form-control" value="<?=$row['email']?>">
				<label>password</label>
				<input type="text" name="password" class="form-control" value="<?=$row['password']?>">
				<br>
				<button type="submit" name="btn" class="btn btn-primary btn-block">update</button>
			</form></div></div></div>
			<?php
			include_once 'footer.php';
			?>