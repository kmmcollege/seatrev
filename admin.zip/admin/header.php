

<!DOCTYPE html>
<html lang="zxx">

<head>
    <title>Edue Web Template | Home :: w3layouts</title>
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta charset="utf-8">
    <meta name="keywords" content="Collegian a Responsive web template, Bootstrap Web Templates, Flat Web Templates, Android Compatible web template, 
Smartphone Compatible web template, free webdesigns for Nokia, Samsung, LG, SonyEricsson, Motorola web design" />
    <script>
        addEventListener("load", function () {
            setTimeout(hideURLbar, 0);
        }, false);

        function hideURLbar() {
            window.scrollTo(0, 1);
        }
    </script>
    <link href="css/bootstrap.css" rel='stylesheet' type='text/css' />
    <link href="css/examples.css" rel="stylesheet" type="text/css">
    <link href="css/slider-pro.css" rel='stylesheet' type='text/css' />
    <link rel="stylesheet" href="css/owl.carousel.css" type="text/css" media="all">
    <link rel="stylesheet" href="css/owl.theme.css" type="text/css" media="all">
    <link href="css/nav.css" rel='stylesheet' type='text/css' />
    <link href="css/style.css" rel='stylesheet' type='text/css' />
    <link href="css/fontawesome-all.css" rel="stylesheet">
    <link rel="stylesheet" type="text/css" href="//cdn.datatables.net/1.10.19/css/jquery.dataTables.min.css">
    <link href="//fonts.googleapis.com/css?family=Nunito:200,200i,300,300i,400,400i,600,600i,700,700i,800" rel="stylesheet">
</head>

<body>
    <div id="example1" class="slider-pro">

        <div class="sp-slides">
            <div class="sp-slide">
                <img class="sp-image" src="images/blank.gif" data-src="images/g6.jpg" alt=" " data-retina="images/banner1.jpg" />

                <h3 class="sp-layer sp-black sp-padding" data-horizontal="40" data-vertical="10%" data-show-transition="left" data-hide-transition="left">
                    Free Online Training Courses
                </h3>

                <p class="sp-layer sp-white sp-padding hide-medium-screen" data-horizontal="40" data-vertical="22%" data-show-transition="left"
                    data-show-delay="200" data-hide-transition="left" data-hide-delay="200">
                    aaaaaaa
                </p>

                <p class="sp-layer sp-black sp-padding hide-small-screen" data-horizontal="40" data-vertical="34%" data-width="350" data-show-transition="left"
                    data-show-delay="400" data-hide-transition="left" data-hide-delay="500">
                    bbbbbbbbbb
                </p>
            </div>

            <div class="sp-slide">
                <img class="sp-image" src="images/blank.gif" data-src="images/banner2.jpg" alt=" " data-retina="images/banner2.jpg" />

                <h3 class="sp-layer sp-black sp-padding" data-horizontal="40" data-vertical="10%" data-show-transition="left" data-hide-transition="left">
                  eeeeeeeee
                </h3>

                <p class="sp-layer sp-white sp-padding hide-medium-screen" data-horizontal="40" data-vertical="22%" data-show-transition="left"
                    data-show-delay="200" data-hide-transition="left" data-hide-delay="200">
                    Ccccccccccccccc
                </p>

                <p class="sp-layer sp-black sp-padding hide-small-screen" data-horizontal="40" data-vertical="34%" data-width="350" data-show-transition="left"
                    data-show-delay="400" data-hide-transition="left" data-hide-delay="500">
                   
            </div>
            <div class="sp-slide">
                <img class="sp-image" src="images/blank.gif" data-src="images/banner3.jpg" alt=" " data-retina="images/banner3.jpg" />

                <h3 class="sp-layer sp-black sp-padding" data-horizontal="40" data-vertical="10%" data-show-transition="left" data-hide-transition="left">
                    Free Online Training Courses
                </h3>

                <p class="sp-layer sp-white sp-padding hide-medium-screen" data-horizontal="40" data-vertical="22%" data-show-transition="left"
                    data-show-delay="200" data-hide-transition="left" data-hide-delay="200">
                   
                </p>

                <p class="sp-layer sp-black sp-padding hide-small-screen" data-horizontal="40" data-vertical="34%" data-width="350" data-show-transition="left"
                    data-show-delay="400" data-hide-transition="left" data-hide-delay="500">
                  
                </p>
            </div>
            <div class="sp-slide">
                <img class="sp-image" src="images/blank.gif" data-src="images/banner4.jpg" alt=" " data-retina="images/banner4.jpg" />

                <h3 class="sp-layer sp-black sp-padding" data-horizontal="40" data-vertical="10%" data-show-transition="left" data-hide-transition="left">
                    
                </h3>

                <p class="sp-layer sp-white sp-padding hide-medium-screen" data-horizontal="40" data-vertical="22%" data-show-transition="left"
                    data-show-delay="200" data-hide-transition="left" data-hide-delay="200">
                    
                </p>

                <p class="sp-layer sp-black sp-padding hide-small-screen" data-horizontal="40" data-vertical="34%" data-width="350" data-show-transition="left"
                    data-show-delay="400" data-hide-transition="left" data-hide-delay="500">
                   
                </p>
            </div>
            <div class="sp-slide">
                <img class="sp-image" src="images/blank.gif" data-src="images/banner5.jpg" alt=" " data-retina="images/banner5.jpg" />

                <h3 class="sp-layer sp-black sp-padding" data-horizontal="40" data-vertical="10%" data-show-transition="left" data-hide-transition="left">
                    
                </h3>

                <p class="sp-layer sp-white sp-padding hide-medium-screen" data-horizontal="40" data-vertical="22%" data-show-transition="left"
                    data-show-delay="200" data-hide-transition="left" data-hide-delay="200">
                    
                </p>

                <p class="sp-layer sp-black sp-padding hide-small-screen" data-horizontal="40" data-vertical="34%" data-width="350" data-show-transition="left"
                    data-show-delay="400" data-hide-transition="left" data-hide-delay="500">
                    
                </p>
            </div>
            <div class="sp-slide">
                <img class="sp-image" src="images/blank.gif" data-src="images/banner3.jpg" alt=" " data-retina="images/banner3.jpg" />

                <h3 class="sp-layer sp-black sp-padding" data-horizontal="40" data-vertical="10%" data-show-transition="left" data-hide-transition="left">
                    Free Online Training Courses
                </h3>

                <p class="sp-layer sp-white sp-padding hide-medium-screen" data-horizontal="40" data-vertical="22%" data-show-transition="left"
                    data-show-delay="200" data-hide-transition="left" data-hide-delay="200">
                    Consectetur adipisicing elit
                </p>

                <p class="sp-layer sp-black sp-padding hide-small-screen" data-horizontal="40" data-vertical="34%" data-width="350" data-show-transition="left"
                    data-show-delay="400" data-hide-transition="left" data-hide-delay="500">
                    Sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation.

                </p>
            </div>

        </div>

        <div class="sp-thumbnails">
            <div class="sp-thumbnail">
                <div class="sp-thumbnail-title">Lorem ipsum</div>
                <div class="sp-thumbnail-description">Dolor sit amet, consectetur adipiscing elit sed</div>
            </div>

            <div class="sp-thumbnail">
                <div class="sp-thumbnail-title">Do eiusmod</div>
                <div class="sp-thumbnail-description">Dolor sit amet, consectetur adipiscing elit sed</div>
            </div>

            <div class="sp-thumbnail">
                <div class="sp-thumbnail-title">Ut enim</div>
                <div class="sp-thumbnail-description">Dolor sit amet, consectetur adipiscing elit sed</div>
            </div>

            <div class="sp-thumbnail">
                <div class="sp-thumbnail-title">Ullamco oris</div>
                <div class="sp-thumbnail-description">Dolor sit amet, consectetur adipiscing elit sed</div>
            </div>

            <div class="sp-thumbnail">
                <div class="sp-thumbnail-title">Duis aute</div>
                <div class="sp-thumbnail-description">Dolor sit amet, consectetur adipiscing elit sed</div>
            </div>
            <div class="sp-thumbnail">
                <div class="sp-thumbnail-title">Ut enim</div>
                <div class="sp-thumbnail-description">Dolor sit amet, consectetur adipiscing elit sed</div>
            </div>

        </div>
        <!--/nav-->
        <div class="top_nav">
            <h1>
                <a class="logo" href="index.html">Collegian</a>
            </h1>
            <div class="container-btn" id="btn">
                <div class="text">Menu</div>
                <div id="bars">
                    <div class="bar first"></div>
                    <div class="bar second"></div>
                    <div class="bar third"></div>
                </div>
            </div>
            <!-- top-overlay -->
            <div class="top-overlay fade-out" id="menu">
                <nav class="top-overlay-content" id="nav">
                    <span class="top-overlay-close" id="close-btn"> &times; </span>
                    <div class="container" id="container">
                        <div class="first-nav text-center">
                            <ul class="first-nav text-center">
                            <li><a href="index.php" class="active">Home</a></li>
                            <li><a href="list.php">List</a></li>
                            <li><a href="collegeadd.php">Team</a></li>
                            <li><a href="gallery.html" class="dropdown">Gallery</a></li>
                              
                            <li class="dropdown">
                              <button class="dropbtn">Dropdown <i class="fas fa-angle-down"></i></button>
                              <div class="dropdown-content">
                                <a href="gallery.html">Gallery</a>
                                <a href="404.html">Error</a>
                                 <a href="service.html">Services</a>
                              </div>
                            </li>
                            <li><a href="contact.html">Course</a></li>
                        </ul>
                        </div>
                    </div>
                </nav>
            </div>
            <!--//nav-->
        </div>
    </div>
    <!---->
  