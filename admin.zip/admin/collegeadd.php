<!DOCTYPE html>
<html>
<head>
</head>
<body>
	<?php
	 require_once 'connect.php'; 
	if(isset($_POST["btn"]))
	{
	$name=$_POST["collegename"];
	$address=$_POST["address"];
	$contact=$_POST["contact"];
	$email=$_POST["email"];
	$password=$_POST["pswd"];
	$sql="select * from college where collegename='$name'";
	$result=mysqli_query($con,$sql);
	if(mysqli_num_rows($result)>0)
{
	echo "college exists";
}
else
{

	$sql="insert into login(email,password,type,status)values ('$email','$password','staff',1)";
	$result=mysqli_query($con,$sql);
	if($result)
	{
		$col_id=$con->col_id;
		$sql="insert into college(col_id,name,address,contact)values('$col_id','$name','$address','$contact')";

		if (mysqli_query($con,$sql))
	 {
		echo "insert success";
	}
	}
}
}
header("location:index.php");
	?>
</body>
</html>