<!DOCTYPE html>
<html>
<head>
</head>
<body>
	<?php
	 require_once 'connect.php'; 
	if(isset($_POST["btn"]))
	{
	$name=$_POST["collegename"];
	$address=$_POST["address"];
	$contact=$_POST["contact"];
	$sql="select * from college where collegename='$name'";
	$result=mysqli_query($con,$sql);
	if(mysqli_num_rows($result)>0)
{
	echo "user exists";
}
else
{

	$sql="insert into college(name,address,contact)values ('$name','$address','$contact')";
	$result=mysqli_query($con,$sql);
	if($result)
	{
		$user_id=$con->insert_id;
		$sql="insert into registration(name,address,contact,gender,user_id)values('$name','$address','$contact','$gender','$user_id')";

		if (mysqli_query($con,$sql))
	 {
		echo "insert success";
	}
	}
}
}
header("location:index.php");
	?>
</body>
</html>