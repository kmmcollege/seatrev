<?php
include_once 'connect.php';
$id=$_GET['id'];
$sql="delete from login where user_id=$id";
if (mysqli_query($con,$sql)) {
?>
<script type="text/javascript">
	alert('deleted');
	window.location="list.php";
</script>
<?php
}
?>